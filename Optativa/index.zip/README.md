[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/kBNebxQW)
# Objetos en JavaScript
 
Los objetos nos permiten agrupar datos y comportamientos y son perfectos para describir entidades del mundo real.

Entra en el tutorial de midudev "https://www.aprendejavascript.dev/" y realiza el apartado de Objetos:
- Objetos
- Atajos y propiedades computadas
- Transformación a Array e iteración
- Operador de encadenamiento opcional

Entrega todos los códigos de manera que sean operativos en GitHub Pages. Añade comentarios con los conceptos tratados en cada código.
