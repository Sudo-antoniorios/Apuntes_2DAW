// ================================================================
// Definición de un objeto con varias propiedades y métodos
// ================================================================
const persona = { 
  name: 'Fernando', // Propiedad tipo string
  age: 19, // Propiedad tipo number
  isWorking: false, // Propiedad tipo boolean
  family: ['Miguel', 'Maria'], // Propiedad tipo array
  address: { // Propiedad tipo objeto anidado
    street: 'Calle de la piruleta',
    number: 13,
    city: 'Córdoba'
  },
  walk: function () { // Método (función dentro del objeto)
    console.log('Estoy caminando')
  }
}

console.log("Definición de un objeto con varias propiedades y métodos")
console.log(persona) // Mostrar todo el objeto

// ================================================================
// Acceder a propiedades directamente usando el nombre de la propiedad
// ================================================================
console.log("Acceder a propiedades directamente usando el nombre de la propiedad")
console.log(persona.name) // -> Fernando

// ================================================================
// Intentar acceder a una propiedad que no existe
// ================================================================
console.log("Intentar acceder a una propiedad que no existe")
console.log(persona.fullName) // -> undefined

// ================================================================
// Acceder a propiedades usando una variable (notación con corchetes)
// ================================================================
console.log("Acceder a propiedades usando una variable (notación con corchetes)")
let property = 'name'
console.log(persona[property]) // -> Fernando

// ================================================================
// Llamar a un método del objeto directamente
// ================================================================
console.log("Llamar a un método del objeto directamente")
persona.walk() // -> Estoy caminando

// ================================================================
// Llamar a un método usando una variable con el nombre del método
// ================================================================
console.log("Llamar a un método usando una variable con el nombre del método")
let method = 'walk'
persona[method]() // -> Estoy caminando

// ================================================================
// Eliminar una propiedad del objeto
// ================================================================
console.log("Eliminar una propiedad del objeto, en este caso 'age'")
delete persona.age

// Mostrar el objeto después de eliminar la propiedad 'age'
console.log(persona) // 'age' ya no aparece

// ================================================================
// Función para crear objetos dinámicamente (factory function)
// ================================================================
function createObject(name, subs) {
  return {
    name: name, // Propiedad basada en parámetro
    subscribers: subs, // Propiedad basada en parámetro
    hash: name.length * subs, // Propiedad calculada
    getStatus: function() { // Método que devuelve un string usando 'this'
      return `El canal de ${this.name} tiene ${this.subscribers} suscriptores`
    }
  }
}

console.log("Función para crear objetos dinámicamente, prueba con 'Fernando' y 1000 suscriptores")
// Uso de la función para crear un nuevo objeto
let canal = createObject('Fernando', 1000)
console.log(canal.getStatus()) // -> El canal de Fernando tiene 1000 suscriptores

// ================================================================
// Creación de objetos usando variables para sus propiedades
// ================================================================
const name = 'Spidey'
const universe = 42

const spiderman = {
  name: name, // Propiedad asignada manualmente
  universe: universe, // Propiedad asignada manualmente
  powers: ['web', 'invisibility', 'spider-sense'] // Array de poderes
}

// ================================================================
// Creación de objetos usando shorthand properties
// ================================================================
const name1 = 'Spidey'
const universe1 = 42

const spiderman1 = {
  name1, // Se asigna automáticamente el valor de la variable name1
  universe1, // Se asigna automáticamente el valor de la variable universe1
  powers: ['web', 'invisibility', 'spider-sense']
}

// ================================================================
// Acceder a propiedades usando notación de punto y corchetes
// ================================================================
const spiderman3 = {
  name: 'Spidey',
  universe: 42,
  powers: ['web', 'invisibility', 'spider-sense']
}

console.log("Acceder a propiedades con notación de corchetes")
console.log(spiderman3['name']) // -> Spidey

console.log("Acceder a propiedades con notación de punto")
console.log(spiderman3.name) // -> Spidey

// ================================================================
// Extraer valores de propiedades y arrays anidados
// ================================================================
const universe2 = spiderman.universe
console.log("Extraer propiedad 'universe'")
console.log(universe2) // -> 42

const powers = spiderman['powers'][1]
console.log("Extraer segundo poder del array 'powers'")
console.log(powers) // -> 'invisibility'

// ================================================================
// Objeto con objeto anidado
// ================================================================
const spiderman5 = {
  name: 'Spidey',
  universe: 42,
  powers: ['web', 'invisibility', 'spider-sense'],
  partner: { // Objeto anidado
    name: 'Mary Jane',
    universe: 42,
    powers: ['red hair', 'blue eyes']
  }
}

// ================================================================
// Recorrer propiedades con for...in
// ================================================================
console.log("Recorrer propiedades con for...in")
for (const property in spiderman) {
  console.log(`${property}: ${spiderman[property]}`)
}

// ================================================================
// Obtener todas las claves (keys) de un objeto
// ================================================================
const properties = Object.keys(spiderman)
console.log("Número de propiedades del objeto")
console.log(properties.length) // -> 3

console.log("Mostrar todas las propiedades")
properties.forEach(property => {
  console.log(property)
})

// ================================================================
// Obtener todos los valores (values) de un objeto
// ================================================================
const values = Object.values(spiderman)
console.log("Mostrar todos los valores del objeto")
values.forEach(value => {
  console.log(value)
})

// ================================================================
// Obtener todas las entradas (entries) de un objeto
// ================================================================
const entries = Object.entries(spiderman)
console.log("Mostrar todas las entradas [clave, valor] del objeto")
entries.forEach(entry => {
  console.log(entry)
})

// ================================================================
// Recorrer entradas para mostrar clave y valor de manera clara
// ================================================================
entries.forEach(entry => {
  const property = entry[0] // Nombre de la propiedad
  const value = entry[1] // Valor de la propiedad
  console.log(`${property}: ${value}`)
})
