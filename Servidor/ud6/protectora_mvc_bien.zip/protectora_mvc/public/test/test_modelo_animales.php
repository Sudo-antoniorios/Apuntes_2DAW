<?php

$animal = new \App\Models\AnimalModel();