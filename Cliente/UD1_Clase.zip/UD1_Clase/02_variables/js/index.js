"use strict" //Obligación de declarar variables/constantes

let nombre = "María";
let apellido = "Ojeda";
const numHijos = 3;

console.log("Me llamo "+nombre+ " " + apellido + " y tengo "+ numHijos+ " hijos.");
console.log(`Me llamo ${nombre} ${apellido} y tengo ${numHijos} hijos.`);


