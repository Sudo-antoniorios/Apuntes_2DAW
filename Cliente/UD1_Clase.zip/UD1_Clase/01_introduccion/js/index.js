alert("Hola mundo!");
console.log("Hola mundo en la consola!");