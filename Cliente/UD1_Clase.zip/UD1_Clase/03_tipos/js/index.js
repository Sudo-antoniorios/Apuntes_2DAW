"use strict" //Obligación de declarar variables/constantes

let nombre="María", numero;
console.log(`El tipo de la variable nombre es ${typeof nombre}`);
console.log(`El tipo de la variable numero1 es ${typeof numero}`);
numero=44;
console.log(`El tipo de la variable numero2 es ${typeof numero}`);
numero=true;
console.log(`El tipo de la variable numero3 es ${typeof numero}`);
numero="44";
console.log(`El tipo de la variable numero4 es ${typeof numero}`);
numero=numero+23;
console.log(`El tipo de la variable numero5 es ${typeof numero} y vale ${numero}`);